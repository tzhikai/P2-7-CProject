#ifndef INPUT_H		// checks if INPUT_H has been defined before, and skips it if it has




// function prototypes
void clean_input(char command[]);




#endif // !INPUT_H
