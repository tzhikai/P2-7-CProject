#ifndef SORT_H
#define SORT_H

int compidup(const void* a, const void* b);
int compiddown(const void* a, const void* b);
int compnameup(const void* a, const void* b);
int compnamedown(const void* a, const void* b);
int compprogrammeup(const void* a, const void* b);
int compprogrammedown(const void* a, const void* b);
int compmarkup(const void* a, const void* b);
int compmarkdown(const void* a, const void* b);

#endif